package org.selenium.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.selenium.base.BasePage;

public class CheckoutPage extends BasePage {
    private final By loginBtnFld= By.cssSelector(".showlogin");
    private final By userNameLoginFld =By.cssSelector("#username");
    private final By userPasswordLoginFld = By.cssSelector("#password");
    private final By clickLoginBtnFld= By.cssSelector("button[value='Login']");
    private final By firstnameFld= By.cssSelector("#billing_first_name");
    private final By lastNameFld= By.cssSelector("#billing_last_name");
    private final By addressLineOneFld= By.cssSelector("#billing_address_1");
    private final By billingCityFld= By.cssSelector("#billing_city");
    private final By billingPostCodeFld= By.cssSelector("#billing_postcode");
    private final By billingEmailFld=By.cssSelector ("#billing_email");
    private final By placeOrderBtn= By.cssSelector("#place_order");
    private final By successNotice= By.cssSelector("#post-1221 > div > div > div > div > div > p");

    public CheckoutPage(WebDriver driver) {
        super(driver);
    }
    public CheckoutPage clickLoginLink(){
        driver.findElement(loginBtnFld).click();
        return this;
    }
    public CheckoutPage putUserNameLogin(String usernameLogin){
        driver.findElement(userNameLoginFld).sendKeys(usernameLogin);
        return this;
    }
    public CheckoutPage putUserPasswordLogin(String PasswordLogin){
        driver.findElement(userPasswordLoginFld).sendKeys(PasswordLogin);
        return this;
    }
    public CheckoutPage clickLoginBtn(){
        driver.findElement(clickLoginBtnFld).click();
        return this;
    }
    public CheckoutPage loginMethod(String usernameLogin, String PasswordLogin){
        return putUserNameLogin(usernameLogin).
                putUserPasswordLogin(PasswordLogin).
                clickLoginBtn();
    }

    public CheckoutPage enterFirstName(String firstName){
        driver.findElement(firstnameFld).sendKeys(firstName);
        return this;
    }
    public CheckoutPage enterLastName(String lastName){
        driver.findElement(lastNameFld).sendKeys(lastName);
        return this;
    }
    public CheckoutPage enterAddressLineOne(String addressLineOne){
        driver.findElement(addressLineOneFld).sendKeys(addressLineOne);
        return this;
    }
    public  CheckoutPage enterCity(String city){
        driver.findElement(billingCityFld).sendKeys(city);
        return this;
    }
    public CheckoutPage enterPostCode (String postCode){
        driver.findElement(billingPostCodeFld).sendKeys(postCode);
        return this;
    }
    public CheckoutPage enterEmail(String email){
        driver.findElement(billingEmailFld).sendKeys(email);
        return this;
    }
    public CheckoutPage placeOrder(){
        driver.findElement(placeOrderBtn).click();
        return this;
    }public String getNotice(){
        return driver.findElement(successNotice).getText();

    }


}
