package org.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.selenium.base.BaseTest;
import org.selenium.pages.CartPage;
import org.selenium.pages.CheckoutPage;
import org.selenium.pages.HomePage;
import org.selenium.pages.StorePage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PrimeraAutomatizacion extends BaseTest {

    @Test
    public void dummyTest () throws InterruptedException {
        StorePage storePage=new HomePage(driver).
                load().
                navigateToStoreUsingMenu().
                enterTextInSearchFld("Blue").
                clickSearchBtn();
        Assert.assertEquals(storePage.getTitle(), "Search results: “Blue”");
        storePage.clickAddToCartBtn("Blue Shoes");
        Thread.sleep(3000);
        CartPage cartPage= storePage.clickViewCart();
        Assert.assertEquals(cartPage.getProductName(),"Blue Shoes");

        CheckoutPage checkoutPage= cartPage.clickCheckoutBtn();
            checkoutPage.
                    enterFirstName("demo").
                    enterLastName("user").
                    enterAddressLineOne("San francisco").
                    enterCity("san francisco").
                    enterPostCode("94188").
                    enterEmail("user@user.com");
                    Thread.sleep(5000);

                    checkoutPage.placeOrder();
            Thread.sleep(5000);
            Assert.assertEquals(checkoutPage.getNotice(), "Thank you. Your order has been received.");






    }




    @Test
    public void logindummyTest2() throws InterruptedException {
        StorePage storePage=new HomePage(driver).
                load().
                navigateToStoreUsingMenu().
                enterTextInSearchFld("Blue").
                clickSearchBtn();
        Assert.assertEquals(storePage.getTitle(), "Search results: “Blue”");
        storePage.clickAddToCartBtn("Blue Shoes");
        Thread.sleep(3000);
        CartPage cartPage= storePage.clickViewCart();
        Assert.assertEquals(cartPage.getProductName(),"Blue Shoes");

        CheckoutPage checkoutPage= cartPage.clickCheckoutBtn();
        checkoutPage.
                clickLoginLink();
                Thread.sleep(3000);
        checkoutPage.loginMethod("user@user.com", "user");

        Thread.sleep(3000);

        checkoutPage.placeOrder();
        Thread.sleep(3000);
        Assert.assertEquals(checkoutPage.getNotice(), "Thank you. Your order has been received.");

    }
}







      /*  // Wait for the element to be clickable before clicking on it
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#menu-item-1227 > a"))).click();

        driver.findElement(By.cssSelector("#woocommerce-product-search-field-0")).sendKeys("Blue");
        driver.findElement(By.cssSelector("button[value='Search']")).click();

        // Wait for the search results header to be visible before proceeding
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".woocommerce-products-header__title.page-title")));

        Assert.assertEquals(
                driver.findElement(By.cssSelector(".woocommerce-products-header__title.page-title")).getText(),
                "Search results: “Blue”"
        );
        driver.findElement(By.cssSelector("a[aria-label='Add “Blue Shoes” to your cart']")).click();
        Thread.sleep(5000);
        driver.findElement(By.cssSelector("a[title='View cart']")).click();

        // Wait for the product name in the cart to be visible before proceeding
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("td[class='product-name'] a")));

        Assert.assertEquals(
                driver.findElement(By.cssSelector("td[class='product-name'] a")).getText(),
                "Blue Shoes"
        );
        driver.findElement(By.cssSelector(".checkout-button.button.alt.wc-forward")).click();
        driver.findElement(By.cssSelector(".showlogin")).click();
        Thread.sleep(3000);

        // Wait for the login form fields to be visible before proceeding
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#username")));
        driver.findElement(By.cssSelector("#username")).sendKeys("user");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#password")));
        driver.findElement(By.cssSelector("#password")).sendKeys("user");

        driver.findElement(By.cssSelector("button[value='Login']")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("#billing_first_name")).clear();
        driver.findElement(By.cssSelector("#billing_first_name")).sendKeys("jeisson");
        driver.findElement(By.cssSelector("#billing_last_name")).clear();
        driver.findElement(By.cssSelector("#billing_last_name")).sendKeys("pulgar");
        driver.findElement(By.cssSelector("#billing_company")).clear();
        driver.findElement(By.cssSelector("#billing_company")).sendKeys("daka");
        driver.findElement(By.cssSelector("#billing_address_1")).clear();
        driver.findElement(By.cssSelector("#billing_address_1")).sendKeys("calle ampies numero 31");
        driver.findElement(By.cssSelector("#billing_address_2")).clear();
        driver.findElement(By.cssSelector("#billing_address_2")).sendKeys("2");
        driver.findElement(By.cssSelector("#billing_city")).clear();
        driver.findElement(By.cssSelector("#billing_city")).sendKeys("new york");
        driver.findElement(By.cssSelector("#billing_postcode")).clear();
        driver.findElement(By.cssSelector("#billing_postcode")).sendKeys("12345");
        driver.findElement(By.cssSelector("#billing_phone")).clear();
        driver.findElement(By.cssSelector("#billing_phone")).sendKeys("6578851");
        driver.findElement(By.cssSelector("#billing_email")).clear();
        driver.findElement(By.cssSelector("#billing_email")).sendKeys("user@user.com");

        driver.findElement(By.cssSelector("#place_order")).click();
        Thread.sleep(3000);



        Assert.assertEquals(
                driver.findElement(By.cssSelector(".woocommerce-notice.woocommerce-notice--success.woocommerce-thankyou-order-received")).getText(),
                "Thank you. Your order has been received."
        );
        driver.quit();
    }


}*/
