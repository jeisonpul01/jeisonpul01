package awesomecucumber.constants;

public class MyConstants {
    public static final String STORE = "/store";
}
