package awesomecucumber.constants;

public enum EnvType {
    PROD,
    STAGE
}
