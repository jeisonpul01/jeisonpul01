package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

import java.util.logging.Logger;

public class LoginStep {
    private static final Logger LOGGER = Logger.getLogger(LoginStep.class.getName());
    @Given("I navigate to the login page")
    public void iNavigateToTheLoginPage() {
        LOGGER.info("Hello Testing");
    }

    @And("I enter the username as admin and password as admin")
    public void iEnterTheUsernameAsAdminAndPasswordAsAdmin() {
    }

    @And("I click login button")
    public void iClickLoginButton() {
    }

    @Then("I should see the userform page")
    public void iShouldSeeTheUserformPage() {
    }
}
