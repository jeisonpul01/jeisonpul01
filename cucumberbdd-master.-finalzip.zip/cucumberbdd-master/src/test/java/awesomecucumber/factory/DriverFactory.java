package awesomecucumber.factory;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverFactory {

    public static WebDriver initializeDriver(String browser){
        WebDriver driver;
        switch (browser) {
            case "chrome" -> {
                // Setup WebDriver using WebDriverManager
                WebDriverManager.chromedriver().setup();

                // Create ChromeOptions instance
                ChromeOptions options = new ChromeOptions();

                // Add desired options/arguments
                options.addArguments("--start-maximized");
                options.addArguments("--remote-allow-origins=*");

                // Initialize WebDriver with ChromeOptions
                driver = new ChromeDriver(options);
            }
            case "firefox" -> {
                WebDriverManager.firefoxdriver().setup();
                driver = new FirefoxDriver();
            }
            default -> throw new IllegalStateException("INVALID BROWSER: " + browser);
        }
        driver.manage().window().maximize();
        return driver;
    }
}
