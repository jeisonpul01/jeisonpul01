package factory;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class DriverFactory {
    private static final ThreadLocal<WebDriver> driverThreadLocal = ThreadLocal.withInitial(() -> null);

    public static WebDriver initializeDriver(String browser) {
        if (driverThreadLocal.get() == null) {
            switch (browser) {
                case "chrome":
                    WebDriverManager.chromedriver().setup();
                    driverThreadLocal.set(new ChromeDriver());
                    break;
                case "firefox":
                    WebDriverManager.firefoxdriver().setup();
                    break;
                default:
                    throw new IllegalStateException("Invalid browser: " + browser);
            }
            getDriver().manage().window().maximize();
        }
        return getDriver();
    }

    public static WebDriver getDriver() {
        return driverThreadLocal.get();
    }

    public static void quitDriver() {
        if (driverThreadLocal.get() != null) {
            driverThreadLocal.get().quit();
            driverThreadLocal.remove();
        }
    }
}
/*
public class DriverFactory {
    private static WebDriver driver;

    public static WebDriver initializeDriver(String browser){
        switch (browser) {
            case "chrome" -> {
                System.setProperty("webdriver.chrome.driver",
                        "C:\\Users\\jeiso\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
                driver = new ChromeDriver();
            }
            case "firefox" -> {
                System.setProperty("webdriver.gekco.driver",
                        "C:\\Users\\jeiso\\Downloads\\chromedriver-win64\\chromedriver-win64\\firefoxdriver.exe");
                driver = new FirefoxDriver();
            }
            default -> throw new IllegalStateException("invalid browser: " + browser);
        }

        driver.manage().window().maximize();
        return driver;
    }
    public static WebDriver getDriver(){
        return  driver;
    }
}
*/
