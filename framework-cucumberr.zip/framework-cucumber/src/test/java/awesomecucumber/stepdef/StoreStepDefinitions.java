package awesomecucumber.stepdef;

import awesomecucumber.apis.CartApi;
import awesomecucumber.constants.EndPoint;
import awesomecucumber.contex.TestContext;
import awesomecucumber.pages.StorePage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import objects.Product;
import org.openqa.selenium.WebDriver;

public class StoreStepDefinitions {
    private TestContext context;
    private final WebDriver driver;
    private final StorePage storePage;
    public StoreStepDefinitions(TestContext context){
        this.context= context;
        driver= context.driver;
        storePage= PageFactoryManager.getStorePage(context.driver);

    }

    @Given("I am on the product page")
    public void iAmOnTheProductPage() {
         storePage.load(EndPoint.STORE.url);


    }
    @When("I add a {product} to the cart")
    public void iAddAToTheCart(Product product)  {
       storePage.addToCart(product.getName());
    }
    @And("I have a product in the cart")
    public void iHaveAProductInTheCart() {
//       storePage.addToCart("Blue Shoes");
        CartApi cartApi = new CartApi(context.cookies.getCookies());
        cartApi.addToCart(1215, 1);
        context.cookies.setCookies(cartApi.getCookies());
        context.cookies.injectCookiesToBrowser(context.driver);

    }
}
