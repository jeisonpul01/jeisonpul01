package awesomecucumber.stepdef;

import awesomecucumber.contex.TestContext;
import awesomecucumber.pages.CartPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import objects.Product;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class CartStepDefinitions {

    private final CartPage cartPage;

    public CartStepDefinitions(TestContext context){
       cartPage= PageFactoryManager.getCartPage(context.driver);
    }

    @Then("I see {int} {product} in the cart")
    public void iSeeInTheCart(int quantity, Product product) {
                Assert.assertEquals(product.getName(), cartPage.getProductName());
        Assert.assertEquals(quantity, cartPage.getProductQuantity());

    }


}
