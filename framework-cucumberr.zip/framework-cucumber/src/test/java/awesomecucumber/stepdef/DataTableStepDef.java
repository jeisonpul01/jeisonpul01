package awesomecucumber.stepdef;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.Given;
import objects.Customer;

import java.util.List;
import java.util.Map;

public class DataTableStepDef {

    @DataTableType
    public Customer customerEntry(List<String> entry){
        return new Customer(entry.get(0), entry.get(1));

    }

    @Given("my credentials")
    public void myCredentials(List<Customer> customers) {
//        List<C>> creds =dataTable.asLists(); //para utiilizar este se agrega DataTable dataTable como argumentos

        System.out.println("ROW 0 USERNAME = " + customers.get(0).getUsername());
        System.out.println("ROW 0 PASSWORD = " + customers.get(0).getPassword());
        System.out.println("ROW 1 USERNAME = " + customers.get(1).getUsername());
        System.out.println("ROW 1 PASSWORD = " + customers.get(1).getPassword());


    }
    /*@Given("my credentials")
    public void myCredentials(List<Map<String, String>> customers) {
//        ignora el encabezado y sigue con las otras dos lineas de la tabla
//        | USERNAME | PASSWORD |
//        | bill     | bill1234 |
//        | jonh     | jonh1234 |

        System.out.println("ROW 0 USERNAME = " + customers.get(0).get("username"));
        System.out.println("ROW 0 PASSWORD = " + customers.get(0).get("password"));
        System.out.println("ROW 1 USERNAME = " + customers.get(1).get("username"));
        System.out.println("ROW 1 PASSWORD = " + customers.get(1).get("password"));



    }*/

    /*@DataTableType
    public Customer customerEntry(Map<String, String> entry){
        return new Customer(entry.get("username"), entry.get("password"));

    }
    @Given("my credentials")
    public void myCredentials(List<Map<String, String>> customers) {

        | USERNAME | PASSWORD |
        | bill     | bill1234 |


        System.out.println(" USERNAME = " + customers.getUsername());
        System.out.println("PASSWORD = " + customers.getPassword());



    }*/
    /*@DataTableType
    public Customer customerEntry(Map<String, String> entry){
        return new Customer(entry.get("username"), entry.get("password"));

    }
    @Given("my credentials")
    public void myCredentials(List<Customer> customers) {

        | USERNAME | PASSWORD |
        | bill     | bill1234 |
        | jonh     | john1234 |


        System.out.println("ROW 0 USERNAME = " + customers.get(0).getUsername());
        System.out.println("ROW 0 PASSWORD = " + customers.get(0)getPassword());
        System.out.println("ROW 1 USERNAME = " + customers.get(1).getUsername());
        System.out.println("ROW 1 PASSWORD = " + customers.get(1)getPassword());

    }*/
    /*@DataTableType
    public Customer customerEntry(Map<String, String> entry){
        return new Customer(entry.get("username"), entry.get("password"));

    }
    @Given("my credentials")
    public void myCredentials(DataTable dataTable) {
    List<String> customer =dataTable.asLists();


         | bill    |
         |bill1234 |  solo columna sin header

        System.out.println(" USERNAME = " + customer.get(0));
        System.out.println(" PASSWORD = " + customer.get(1));


    }*/
    
    /*@DataTableType
    public Customer customerEntry(Map<String, String> entry){
        return new Customer(entry.get("username"), entry.get("password"));

    }
    @Given("my credentials")
    public void myCredentials(DataTable dataTable) {
    Map<String, String> customer =dataTable.asMap();


         |username | bill    |
         |password |bill1234 |

        System.out.println(" USERNAME = " + customer.get("username"));
        System.out.println(" PASSWORD = " + customer.get("password"));


    }
        /*@DataTableType
    public Customer customerEntry(List<String> entry){
        return new Customer(entry.get(0), entry.get(1));

    }
    @Given("my credentials")
    public void myCredentials(@Transpose Customer customer) {



         | bill    |
         |bill1234 |

        System.out.println(" USERNAME = " + customer.getUsername());
        System.out.println(" PASSWORD = " + customer.getPassword());


    }*/
    /*@DataTableType
    public Customer customerEntry(Datatable dataTable){
    dataTable.row(0);
        return new Customer( dataTable.row(0).get(1),  dataTable.row(1).get(1));

        @Given("my credentials")
    public void myCredentials( Customer customer) {



         |username | bill    |
         |password |bill1234 |

        System.out.println(" USERNAME = " + customer.getUsername());
        System.out.println(" PASSWORD = " + customer.getPassword());


    }*/





}

