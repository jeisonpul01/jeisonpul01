package awesomecucumber.stepdef;

import awesomecucumber.constants.EndPoint;
import awesomecucumber.contex.TestContext;
import awesomecucumber.pages.StorePage;
import io.cucumber.java.en.Given;
import org.openqa.selenium.WebDriver;

public class CustomerStepDefinitions {

    private final StorePage storePage;
    public CustomerStepDefinitions(TestContext context){

        storePage= PageFactoryManager.getStorePage(context.driver);

    }

    @Given("I am a guest customer")
    public void iAmAGuestCustomer() {

        storePage.load(EndPoint.STORE.url);
    }
}
