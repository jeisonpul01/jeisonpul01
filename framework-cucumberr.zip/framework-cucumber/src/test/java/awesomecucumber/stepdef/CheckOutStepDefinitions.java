package awesomecucumber.stepdef;

import awesomecucumber.constants.EndPoint;
import awesomecucumber.contex.TestContext;
import awesomecucumber.pages.CartPage;
import awesomecucumber.pages.CheckoutPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class CheckOutStepDefinitions {

    private final CheckoutPage checkoutPage;
    public CheckOutStepDefinitions(TestContext context){
       checkoutPage = PageFactoryManager.getCheckoutPage(context.driver);
    }




    @When("I provide  billing  details")
    public void iProvideBillingDetails(List<Map<String, String>> billingDetails) throws InterruptedException {
       checkoutPage.enterDataTable(billingDetails);
    }

    @And("I place an order")
    public void iPlaceAnOrder() throws InterruptedException {
        checkoutPage.clickPlaceOrderBtn();
    }

    @Then("The order should be placed successfully")
    public void theOrderShouldBePlacedSuccessfully() {
        checkoutPage.verifyOrder();
    }
    @And("i am on the Checkout page")
    public void iAmOnTheCheckoutPage() {
        checkoutPage.load(EndPoint.CHECKOUT.url);
    }
}
