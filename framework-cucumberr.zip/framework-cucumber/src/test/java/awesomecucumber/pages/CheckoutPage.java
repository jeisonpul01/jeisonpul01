package awesomecucumber.pages;

import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import java.time.Duration;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.List;
import java.util.Map;

public class CheckoutPage extends BasePage{
    public CheckoutPage(WebDriver driver) {
        super(driver);
    }
    private final By billingFirstnameFld = By.id("billing_first_name");
    private final By billingLastNameFld= By.id("billing_last_name");
    private final By billingAddressOneFld= By.id("billing_address_1");
    private final By billingCityFld= By.id("billing_city");
    private final By billingStateDropDown= By.id("billing_state");

    private final By billingZipFld= By.id("billing_postcode");
    private final By billingEmailFld= By.id("billing_email");
    private final By stateDropDownList = By.id("p[id='billing_state_field'] span span[dir='ltr'] span span[aria-label='State']");
    private final By placeOrderBtn= By.id("place_order");
    private final By noticeTxt = By.cssSelector(".woocommerce-notice");
    private final By overlay= By.cssSelector(".blockUI.blockOverlay");





    public CheckoutPage enterDataTable(List<Map<String, String>> billingDetails) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(billingFirstnameFld));
        driver .findElement( billingFirstnameFld).clear();
        driver.findElement( billingFirstnameFld).sendKeys(billingDetails.get(0).get("firstname"));
        driver .findElement( billingLastNameFld).clear();
        driver.findElement( billingLastNameFld).sendKeys(billingDetails.get(0).get("lastname"));
        driver .findElement( billingAddressOneFld).clear();
        driver.findElement( billingAddressOneFld).sendKeys(billingDetails.get(0).get("address_line1"));
        driver .findElement( billingCityFld).clear();
        driver.findElement( billingCityFld).sendKeys(billingDetails.get(0).get("city"));



            String textOfDropDown = "Texas";
            WebElement stateDropdown = driver.findElement(By.id("billing_state"));
            Select select = new Select(stateDropdown);
            List<WebElement> options = select.getOptions();

            for (WebElement option : options) {
                if (option.getText().equalsIgnoreCase(textOfDropDown)) {
                    option.click();
                    break;
                }
            }


        driver .findElement( billingZipFld).clear();
        driver.findElement( billingZipFld).sendKeys(billingDetails.get(0).get("zip"));
        driver .findElement( billingZipFld).clear();
        driver.findElement( billingZipFld).sendKeys(billingDetails.get(0).get("zip"));
        driver .findElement( billingEmailFld).clear();
        driver.findElement( billingEmailFld).sendKeys(billingDetails.get(0).get("email"));

    return this;}

    public CheckoutPage clickPlaceOrderBtn() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderBtn));
        wait.until(ExpectedConditions.visibilityOfElementLocated(placeOrderBtn));
        waitForOverlaysToDisappear(overlay);
        driver.findElement(placeOrderBtn).click();
        return this;
    }

    public CheckoutPage verifyOrder(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(noticeTxt));
        String actualNoticeMsg= driver.findElement(noticeTxt).getText();
        Assert.assertEquals(actualNoticeMsg, "Thank you. Your order has been received.");
        return this;
    }
}
