package awesomecucumber.runners;


import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

@CucumberOptions(

        plugin ={"pretty", "html:target/cucumber.html", "summary"},
        snippets = CucumberOptions.SnippetType.CAMELCASE,
 //       dryRun = true, /*found step definitions missing*/
        monochrome = false /*change the color letter to white for readability*/,
        tags = "@prueba2",
        glue = {"awesomecucumber.stepdef", "awesomecucumber.hooks", "awesomecucumber.types"},
        features = "src/test/resources/awesomecucumber"


/*mvn clean test -Dcucumber.filter.tags="@prueba1" -Dcucumber.features="src/test/resources/awesomecucumber" -Dcucumber.glue="awesomecucumber.stepdef,awesomecucumber.hooks,awesomecucumber.types"

*/

)
public class TestNGRunnerTest extends AbstractTestNGCucumberTests {
    @DataProvider(parallel = true) // Habilita la ejecución en paralelo
    public Object[][] scenarios() {
        return super.scenarios();

    }

    @BeforeClass
    public void beforeClass(){
        System.out.println("\nIn BEFORE CLASS\n");
    }
    @AfterClass
    public void afterClass(){
        System.out.println("\nIn AFTER CLASS\n");
    }

}
